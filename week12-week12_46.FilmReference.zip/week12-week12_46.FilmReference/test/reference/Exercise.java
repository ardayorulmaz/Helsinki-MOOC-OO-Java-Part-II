package reference;

public class Exercise {
    public static final String ID = "46";
}
