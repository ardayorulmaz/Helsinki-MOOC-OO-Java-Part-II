
public class Main {

    public static void main(String[] args) {

        Interface ski = new Interface();
        ski.initialize();
        ski.results();
        // Write your main program here. Implementing your own classes will be very useful.
    }
}
